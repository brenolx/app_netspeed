import speedtest
import sys

speed = speedtest.Speedtest()

def speed_down():
	speed_download = speed.download()

def speed_up():
	speed_upload = speed.upload()

def ajuda():
	print('net-speed -> Exibe a velocidade de (Upload) e (Download)\n --help -> Exibe ajuda de comandos\n')

def img_menu():
	print('\t\t' + ' ' + 16 * '=')
	print('\t\t' +  ' |NET-SPEED 1.0||')
	print('\t\t' + ' ' + 16 * '=')
	print('\n')
	print('\t\t--help -> para ajuda\n\n\n\n')

def opcao_usu():
	while(True):

		op_usu = input('>>')
	
		if op_usu == '--help' or op_usu == '--h':
			print(ajuda())
		elif op_usu == '--net-speed' or op_usu == '--ns':
			print('Download: ' + speed_down())
			print('Upload: ' + speed_up())
		elif op_usu == '--exit' or op_usu == 'e':
			print('aplication finalizated')
			sys.exit()
		else:
			ajuda()
			

def main():
	img_menu()
	opcao_usu()


if __name__ == "__main__":
	main()
